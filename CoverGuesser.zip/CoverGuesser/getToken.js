const client_id = '060054337fc14683a5cd130a6abf488b';
const client_secret = 'c00bd8a38fbe49ffac7e238b59aaffab';
const grant_type = 'client_credentials';
const token_url = 'https://accounts.spotify.com/api/token';

const base64encoded = btoa(`${client_id}:${client_secret}`);

const headers = {
  'Content-Type': 'application/x-www-form-urlencoded',
  'Authorization': `Basic ${base64encoded}`,
};

const data = {
  'grant_type': grant_type,
};

const params = Object.keys(data).map((key) => {
  return encodeURIComponent(key) + '=' + encodeURIComponent(data[key]);
}).join('&');

fetch(token_url, {
  method: 'POST',
  headers: headers,
  body: params,
})
.then((response) => response.json())
.then((data) => console.log(data))
.catch((error) => console.error(error));