//Source: https://developer.spotify.com/console/get-playlist-tracks/?playlist_id=37i9dQZEVXbKQ1ogMOyW9N&market=FR&fields=&limit=&offset=&additional_types=
// Replace YOUR_ACCESS_TOKEN with your Spotify access token


const fs = require('fs');




const accessToken = 'BQBUV6viMXx8Tkc8xi4wiIeOP1e2kCVPSrUg5bMycE3xV3EQc3zMLbfsDa0r6uAv4KsEKwlPNJTvZeXTzArmr1_kfNZvcSfOcApmw6EafwZ00Ro6Bp9j';

// Replace PLAYLIST_ID with the ID of the playlist you want to get tracks from
const playlistId = '3tBK0zMvn0Q07ZHjKIVyKi';

// Make a GET request to the Spotify API to get the playlist tracks
fetch(`https://api.spotify.com/v1/playlists/${playlistId}/tracks`, {
  headers: {
    'Authorization': `Bearer ${accessToken}`,
  },
})
.then(response => response.json())

.then(data => {
  console.log(data); // check the structure of the data
  // Extract the track names and artists from the response data
  const tracks = data.items.map(item => {
    const track = item.track;
    return {
      name: track.name,
      artist: track.artists[0].name,
      cover: track.album.images[0].url,
      song: track.preview_url,
    };
  });

  // Log the track names and artists to the console
  tracks.forEach(track => {
    console.log(`${track.name} / ${track.artist} \n     url: ${track.cover}\n     ${track.song}`);
    var data = `${track.name} / ${track.artist} / ${track.cover} / ${track.song}\n`;
    fs.appendFile('rock.csv', data, (err) => {
      if (err) throw err;
      console.log('Text added to file');
    });
  });
})
.catch(error => console.error(error));
