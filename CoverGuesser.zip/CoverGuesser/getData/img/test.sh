#!/bin/bash

IMAGE_CARRE="ab67616d0000b273b8d28a4979da5227dd3005c4"
VIDEO_WIDTH=1080
VIDEO_HEIGHT=1920
VIDEO_DURATION=10

# Créer une vidéo blanche de la durée et de la résolution souhaitées
ffmpeg -f lavfi -i color=c=white:s=${VIDEO_WIDTH}x${VIDEO_HEIGHT}:d=${VIDEO_DURATION} -vf "scale=${VIDEO_WIDTH}:${VIDEO_HEIGHT}" -y white.mp4

# Redimensionner l'image carrée pour la placer au centre de l'écran
ffmpeg -i ${IMAGE_CARRE} -vf "scale=iw*min(${VIDEO_WIDTH}/iw\,${VIDEO_HEIGHT}/ih):ih*min(${VIDEO_WIDTH}/iw\,${VIDEO_HEIGHT}/ih), pad=${VIDEO_WIDTH}:${VIDEO_HEIGHT}:(${VIDEO_WIDTH}-iw)/2:(${VIDEO_HEIGHT}-ih)/2" -y square.jpg

# Superposer l'image carrée sur la vidéo blanche
ffmpeg -i white.mp4 -i square.jpg -filter_complex "overlay" -y tiktok.mp4

# Supprimer les fichiers temporaires
rm white.mp4 square.jpg
