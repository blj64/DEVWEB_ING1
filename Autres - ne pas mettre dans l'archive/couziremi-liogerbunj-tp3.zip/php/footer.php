    <link rel="stylesheet" type="text/css" href="css/index.css">
        <footer id="footer">
        <span id="copyright">© 2023 Rockhub. All rights reserved.
            <br></span>
        <span id="footer-text">Created by Couzi Remi and Lioger--Bun Jérémi, students at CY TECH</span>   
    </footer>
    </div>
    </body>
</html>
