## __DEVWEB_ING1__

Site web Ing 1 GI, second rendu

# JavaScript
Nous avons fait les verifications du formulaire de contact en JS.
Nous avons mis de coté la partie permettant de gerer les stocks car ceux-ci sont présents dans le JSON des produits maintenant.
Nous avons implémenté un panier dynamique, il suffit d'appuyer sur les "-" ou "+" d'un produit, reliés à des fonctionsJS  puis "Ajouter au panier" pour effectuer l'action avec JS

# PHP
Majoritairement utilisé, il sert à faire quasiment toutes les actions présentes sur le site (panier, formulaire, inscription/connexion, listing des produits).
Un header et un footer sont inclus sur toutes les pages.

# JSON/CSV
Nous avons utilisé un json pour lister les produits en vente sur le site.
Ainsi qu'un CSV pour stocker les utilisateurs enregistrés sur le site.
Un compte par défaut est login = "defaut" et mot de passe = "defaut"

# CSS
Certaines images ont un effet lors du hover

## Execution
Il suffit de faire les commande ci-dessous pour ouvrir le site

- php -S localhost:8080
- firefox http://localhost:8080/index.php

# Crédits

Jérémi Lioger--Bun
Rémi Couzi
ING1 GI Groupe 3