## __DEVWEB_ING1__

Site web Ing 1 GI, premier rendu

# JavaScript
Nous avons commencé l'implémentation du panier en JS.
# CSS
Certaines images ont un effet lors du hover
## Execution
Il suffit de faire la commande ci-dessous pour ouvrir le site

- firefox index.html

# Crédits

Jérémi Lioger--Bun
Rémi Couzi
ING1 GI Groupe 3